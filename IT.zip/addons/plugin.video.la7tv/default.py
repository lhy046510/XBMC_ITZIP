# Version 1.0.3 (21/11/2011)
# LA7 TV
# Italian News Channel
# By K.Mantzaris
# kmanjaris@gmail.com
# http://SlaXBMC.blogspot.com
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#######################################################################
import sys,os,xbmc,urllib,urllib2,re,datetime,time,HTMLParser,xbmcplugin,xbmcgui,xbmcaddon
from urllib import urlretrieve
__settings__ = xbmcaddon.Addon(id='plugin.video.la7tv')
__language__ = __settings__.getLocalizedString


#LA7 TV Category Menu
def CATEGORY():
        req = urllib2.Request("http://www.la7.tv/xml/epg/index.xml")
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link.replace('\t','').replace('\r\n','').replace('\n','').replace('" />','"/>')
        match=re.compile('<show channel="(.+?)" title="(.+?)" linkUrl="(.+?)<logo src="(.+?)"/>').findall(link)
        for buffer1, name,buffer2,thumb in match:
                outfile = os.path.join(__settings__.getAddonInfo('path'),'resources','images',thumb.split('/')[-1])
                if not os.path.isfile(outfile):
                        urlretrieve(thumb, outfile)
                addDir(name.upper(),name,1,outfile)

#LA7 TV Videos
def VIDEOLINKS(url):
        getDate = xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"display_date")
        getQuality = xbmcplugin.getSetting(int( sys.argv[ 1 ] ),"vid_quality")
        req = urllib2.Request("http://www.la7.tv/xml/epg/index.xml")
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=link.replace('\t','').replace('\r\n','').replace('\n','').replace('" />','"/>')
        catblock=re.compile(' title="'+url+'" linkUrl="(.+?)</show>').findall(link)
        epgDate=re.compile('<epg startDate="(.+?)">').findall(link)
        match=re.compile('<item pos="(.+?)" linkUrl="(.+?)<img src="(.+?)"/> <video url="mp4:(.+?)"/>(.+?)<!\[CDATA\[(.+?)\]\]>').findall(str(catblock))
        for datepos,buffer1,thumb,url,buffer2,name in match:
                name = NormaliseName(name,getDate) + CalculateDate(epgDate[0],datepos,getDate)
                url = SetVideoQuality(url,getQuality)
                addLink(name,"rtmp://yalpvod.alice.cdn.interbusiness.it:1935/vod"+url,thumb)

def CalculateDate(curDate, DatePos, sDate):
        if sDate == "true":
                StartDate=datetime.datetime(*(time.strptime(curDate, '%m/%d/%Y')[0:6]))
                vidDate=StartDate+datetime.timedelta(days=int(DatePos))
                return " ("+vidDate.strftime("%d %b %Y")+")"
        else:
                return ""

def NormaliseName(sInput, sDate):
        sInput = sInput.replace('\\','').replace('-',' - ').replace('  ',' ').replace(' 20 ',' 20:00 ').upper()
        if sDate == "true":
                if sInput.find('-') >= 0:
                        aInput=sInput.split('-')
                        sInput=aInput[0]
        return sInput.strip()

def SetVideoQuality(sURL, sQlty):
        if sQlty == "0":
                if sURL.find('_400.mp4') >= 0:
                        return sURL.replace('_400.mp4','_800.mp4')
                else:
                        return sURL
        if sQlty == "1":
                if sURL.find('_800.mp4') >= 0:
                        return sURL.replace('_800.mp4','_400.mp4')
                else:
                        return sURL

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        icoimg = os.path.join(__settings__.getAddonInfo('path'),iconimage)
        if icoimg.count('http:') > 0:
                icoimg=iconimage
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=icoimg)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


if mode==None or url==None or len(url)<1:
        print ""
        CATEGORY()
elif mode==1:
        print ""+url
        VIDEOLINKS(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
